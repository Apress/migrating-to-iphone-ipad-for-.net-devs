//
//  HighScore.h
//  DataStorage
//
//  Created by Mark Mamone on 16/08/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

// HighScoreEntry class
//
@interface HighScoreEntry : NSObject {
    NSString * name;
    int score;
}
-(id)initWithParameters:(NSString*)aName:(int)Score;
@property (readwrite, retain) NSString* name;
@property (readwrite) int score;

@end

// HighScore class
//
@interface HighScore : NSObject {
    NSMutableArray *scores;
}
-(void)addHighScoreEntry:(HighScoreEntry *)score;
-(void)persist;
-(void)readHighScores;
@end