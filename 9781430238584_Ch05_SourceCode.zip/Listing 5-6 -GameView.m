//
//  GameView.m
//  LunarLander
//
//  Created by Mark Mamone on 17/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GameView.h"

@implementation GameViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    // Create an instance of the timer every (0.025) 1/4 of a second, to fire the 'timerLoop' function
    gameLoop = [NSTimer scheduledTimerWithTimeInterval: 0.025 target:self selector:@selector(timerLoop:) userInfo:nil repeats:YES];    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

// timeLoop - main Timer event function
-(void)timerLoop:(NSTimer *)timerObj
{
    // Update the Landers postion
    [(GameView *)self.view updateLander];
    
    // Redisplay the whole view
    [self.view setNeedsDisplay];
    
}

// User has indicated that want to fire the thruster engines, pass this onto the game
//
-(void)quitGame:(id)sender
{
    // No longer require the game window, go back to parent
    [ self dismissModalViewControllerAnimated:YES ];
}

// User has indicated that want to fire the thruster engines, pass this onto the game
//
-(void)rotateLeft:(id)sender
{
    [(GameView *)self.view rotateLeft:sender];
}

// User has indicated that want to fire the thruster engines, pass this onto the game
//
-(void)rotateRight:(id)sender
{
    [(GameView *)self.view rotateRight:sender];
}

// User has indicated that want to fire the thruster engines, pass this onto the game
//
-(void)thrust:(id)sender
{
    [(GameView *)self.view thrustEngine:sender];
}

@end

@implementation GameView

@synthesize lander_nothrust = plander_nothrust;


// initWithCode - called when we programmatically initialse our XIB resource
//
- (id) initWithCoder:(NSCoder *)aDecoder
{
    if (self == [super initWithCoder:aDecoder]) {
        
        //// Initialise the sprites
        //
        NSString *imagePath = [[ NSBundle mainBundle] pathForResource:@"lander" ofType:@"tiff"];
        self.lander_nothrust = [UIImage new];
        self.lander_nothrust = [UIImage imageWithContentsOfFile:imagePath];
        
        // Set initial game state
        [self newGame];
        
    }
    return self;    
}

-(void)dealloc
{
//    [self.lander_nothrust release];
    [super dealloc];
}

// newGame - Initialises a new game
//
-(void) newGame
{
    gstate = READY;
    level = EASY;
    thrusters = THRUSTERS_OFF;
    fuel = FUEL_INITIAL;
    loc_x = self.frame.size.width / 2;
    loc_y = self.frame.size.height / 2;
    
    // Set the game as RUNNING
    gstate = RUNNING;
}

// updateLander - Updates the lander position\state based on gravity and any user input
- (void) updateLander
{
    // *TODO
}

// drawRect - ReDraw the screen
-(void)drawRect:(CGRect)rect
{
    // Only draw when we're ready to draw
    if (gstate != RUNNING)
        return;
    
    [self.lander_nothrust drawAtPoint:CGPointMake(loc_x, loc_y)];
    
}

// rotateLeft - rotate the lander left
- (void)rotateLeft:(id)sender
{
    // Do Something
}

// rotateRight - rotate the lander right
- (void)rotateRight:(id)sender
{
    // Do Something
}

// thrustEngine - fire the thruster on the egine
- (void)thrustEngine:(id)sender
{
    // Do Something
}

@end
