//
//  LunarLanderViewController.h
//  LunarLander
//
//  Created by Mark Mamone on 17/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

// Inform the compilate that our GameViewController reference is to a class
@class GameViewController;

// Define the main Class or Interface as its known in Objective-C, inheriting from UIViewController
@interface LunarLanderViewController : UIViewController {

    @private GameViewController *pgameViewController;
}

// Property we'll use to refer to our ViewController
@property (nonatomic, retain) GameViewController *gameViewController;

// Event we'll use to attach to the Start Game button for the user to commence game play
-(IBAction)startGame:(id)sender;

@end
