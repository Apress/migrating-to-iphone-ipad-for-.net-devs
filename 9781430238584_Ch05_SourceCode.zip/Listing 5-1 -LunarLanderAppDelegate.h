//
//  LunarLanderAppDelegate.h
//  LunarLander
//
//  Created by Mark Mamone on 17/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LunarLanderViewController;

@interface LunarLanderAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet LunarLanderViewController *viewController;

@end
