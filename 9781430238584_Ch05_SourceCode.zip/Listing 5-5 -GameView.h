//
//  GameView.h
//  LunarLander
//
//  Created by Mark Mamone on 17/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

// GameView class manages the games view controller
//
@interface GameViewController : UIViewController {
    
    NSTimer *gameLoop;  // Core game timer
}

// Declare class events for our view controller
- (void)timerLoop:(NSTimer *)timeObj;   // Timer event loopr
-(IBAction)quitGame:(id)sender;
-(IBAction)rotateLeft:(id)sender;
-(IBAction)rotateRight:(id)sender;
-(IBAction)thrust:(id)sender;

@end

// Declaration of some enumerated types to avoid lots of messy constant definitions
typedef enum { NOTREADY, READY, RUNNING, WON, LOST, PAUSED } GameState;
typedef enum { EASY, MEDIUM, HARD } GameDifficulty;
typedef enum { THRUSTERS_ON, THRUSTERS_OFF } ThrusterState;

// Declaration of other constants used to manage the physics
static const int FUEL_INITIAL = 1000;
static const int FUEL_MAX = 200;
static const int FUEL_BURN = 10;
static const int MAX_INIT = 30;
static const int MAX_SPEED = 120;
static const int ACCELERATION_DOWN = 35;
static const int ACCELERATION_UP = 80;
static const double GRAVITY = 9.8;

// GameView class manages the main Game
//
@interface GameView : UIView {

    // Images to hold the lander state
    @private UIImage            *plander_thrust;
    @private UIImage            *plander_nothrust;
    @private UIImage            *plander_crashed;
    
    // Other game member variables
    @private GameState          gstate;    
    @private GameDifficulty     level;
    @private ThrusterState      thrusters;
    @private int                fuel;
    @private int                speed_x;
    @private int                speed_y;
    @private double             rotation;
    
    // Define our landers X and Y on-screen co-ordinaes
    @private int loc_x;
    @private int loc_y;
}

// Declare our member properties
@property (nonatomic, retain) UIImage *lander_nothrust;

// Declare our class methods
- (void) newGame;
- (void) updateLander;
- (void) rotateLeft:(id)sender;
- (void) rotateRight:(id)sender;
- (void) thrustEngine:(id)sender;

@end
