//
//  CameraExampleViewController.h
//  CameraExample
//
//  Created by Mark Mamone on 18/09/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MobileCoreServices/UTCoreTypes.h>

@interface CameraExampleViewController : UIViewController 
            <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    
    UIImageView *imageView;
    BOOL newMediaAvailable;
}
@property (nonatomic, retain) IBOutlet UIImageView *imageView;
- (IBAction)useCamera;
- (IBAction)useCameraRoll;
@end
