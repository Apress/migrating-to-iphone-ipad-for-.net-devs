//
//  MainViewController.m
//  StaticLibraryHarness
//
//  Created by Mark Mamone on 18/08/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"
#import "HighScore.h"

@implementation MainViewController

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    HighScore *hs = [[HighScore alloc]init];
 
    HighScoreEntry *e1 = [[HighScoreEntry alloc]initWithParameters:@"Mark":900];
    [hs addHighScoreEntry:(e1)];
 
    HighScoreEntry *e2 = [[HighScoreEntry alloc]initWithParameters:@"Rachel":700];
    [hs addHighScoreEntry:(e2)];
 
    HighScoreEntry *e3 = [[HighScoreEntry alloc]initWithParameters:@"Oliver":500];
    [hs addHighScoreEntry:(e3)];
 
    HighScoreEntry *e4 = [[HighScoreEntry alloc]initWithParameters:@"Harry":300];
    [hs addHighScoreEntry:(e4)];
 
    HighScoreEntry *e5 = [[HighScoreEntry alloc]initWithParameters:@"Tanya":100];
    [hs addHighScoreEntry:(e5)];
 
    [hs persist];
 
    [hs readHighScores];
 
    [hs release];

}


- (void)flipsideViewControllerDidFinish:(FlipsideViewController *)controller
{
    [self dismissModalViewControllerAnimated:YES];
}

- (IBAction)showInfo:(id)sender
{    
    FlipsideViewController *controller = [[FlipsideViewController alloc] initWithNibName:@"FlipsideView" bundle:nil];
    controller.delegate = self;
    
    controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    [self presentModalViewController:controller animated:YES];
    
    [controller release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload
{
    [super viewDidUnload];

    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [super dealloc];
}

@end
