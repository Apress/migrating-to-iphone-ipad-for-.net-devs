//
//  HighScore.m
//  DataStorage
//
//  Created by Mark Mamone on 16/08/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HighScore.h"
#import "/usr/include/sqlite3.h"

// HighScoreEntry class
//
@implementation HighScoreEntry

-(id)initWithParameters:(NSString*)aName:(int)aScore
{
    self = [super init];
    if (self)
    {
        name = [aName copy];
        score = aScore;
    }
    return self;
}

@synthesize name;
@synthesize score;

@end

// HighScore class
//
@implementation HighScore
-(void)addHighScoreEntry:(HighScoreEntry *)score
{
    if (scores == nil)
        scores = [[NSMutableArray alloc] init];
    
    [scores addObject:(score)];
}

-(void)persist
{
    // Open our database
    sqlite3 *db;
    int result = sqlite3_open("mydb.sqlite3", &db);
    if (result == SQLITE_OK)
    {
        // CREATE TABLE
        char *errMsg;
        const char *sql = "CREATE TABLE IF NOT EXISTS HIGHSCORE (NAME TEXT, SCORE INTEGER)";
        if (sqlite3_exec(db, sql, NULL, NULL, &errMsg) == SQLITE_OK)
        {
            
            // DELETE from the table
            const char *sqldelete = "DELETE FROM HIGHSCORE";
            sqlite3_exec(db, sqldelete, NULL, NULL, &errMsg);

            // WRITE ARRAY TO TABLE
            int idx = 0;
            char *insert_sql = "INSERT INTO HIGHSCORE VALUES(?, ?);";
            sqlite3_stmt *stmt;
            while (idx < [scores count])
            {
                // Prepare our statement for binding
                if (sqlite3_prepare_v2(db, insert_sql, -1, &stmt, nil) == SQLITE_OK) {
                    // Get entry
                    HighScoreEntry *hse = [scores objectAtIndex:(idx)];
                    
                    // Bind the name
                    sqlite3_bind_text(stmt, 1, [hse.name UTF8String], -1, NULL);   // NAME
                    // Bind the score
                    sqlite3_bind_int(stmt, 2, hse.score);   // SCORE
                    // Step and Finalise the write
                    sqlite3_step(stmt);
                    sqlite3_finalize(stmt);
                    // Next item
                    idx++;
                }
            }
            // READ FROM TABLE
            sqlite3_stmt *readstmt;
            const char *readSQL = "SELECT NAME, SCORE FROM HIGHSCORE";
            sqlite3_prepare_v2(db, readSQL, -1, &readstmt, NULL);
            while (sqlite3_step(readstmt) == SQLITE_ROW)
            {
                NSString *name = [[NSString alloc] initWithUTF8String:(const char *)sqlite3_column_text(readstmt,0)];
                NSString *score = [[NSString alloc] initWithUTF8String:(const char *)sqlite3_column_text(readstmt,1)];
                NSLog (@"NAME: %@ SCORE: %@", name, score );
                
            }
        } else NSLog(@"Failed to create table");
        
    } else NSLog(@"Failed to open database");    
}
// readHighScores method
-(void)readHighScores
{
    // Open our database
    sqlite3 *db;
    int result = sqlite3_open("mydb.sqlite3", &db);
    if (result == SQLITE_OK)
    {
        // We've opened the database, so let's cleaer our array
        [scores removeAllObjects]; 
        
        // READ FROM TABLE
        sqlite3_stmt *readstmt;
        const char *readSQL = "SELECT NAME, SCORE FROM HIGHSCORE";
        sqlite3_prepare_v2(db, readSQL, -1, &readstmt, NULL);
        while (sqlite3_step(readstmt) == SQLITE_ROW)
        {
            NSString *name = [[NSString alloc] initWithUTF8String:(const char *)sqlite3_column_text(readstmt,0)];
            int score = (const int)sqlite3_column_int(readstmt,1);
            HighScoreEntry *e = [[HighScoreEntry alloc]initWithParameters:name:score];
            [self addHighScoreEntry:(e)];
            [e release];
        } 
    } else NSLog(@"Failed to open database");    
}

@end